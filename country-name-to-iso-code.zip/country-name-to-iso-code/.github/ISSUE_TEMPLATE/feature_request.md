---
name: Feature request / Novo país ou variação
about: Sugira uma melhoria ou uma nova variação de nome de país
title: "[FEATURE] "
labels: enhancement
---

**Sua sugestão**
Descreva a melhoria ou a variação de nome de país que deveria ser reconhecida.

**Exemplo de entrada → saída esperada**
Ex.: `Holanda` → `nl`

**Contexto adicional**
Qualquer informação extra que ajude a avaliar a sugestão.
