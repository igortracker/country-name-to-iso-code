---
name: Bug report
about: Reporte um problema com o template
title: "[BUG] "
labels: bug
---

**Descrição do problema**
Descreva claramente o que aconteceu.

**Entrada usada**
Valor passado em "Nome do país" (e "Valor padrão", se houver):

**Resultado esperado**
Qual código ISO você esperava.

**Resultado obtido**
O que a variável retornou.

**Ambiente**
- Container: server-side (sGTM)
- Versão do template (SHA ou data):
